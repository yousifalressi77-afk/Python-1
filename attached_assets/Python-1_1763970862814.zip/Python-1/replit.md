# 🤖 PrimeBot - Discord Bot

## 📋 مقدمة
بوت Discord احترافي مع دعم اللغة العربية الكاملة و45 أمر متقدمة.

**المالك:** ALSHARQI

---

## ✨ الميزات الرئيسية

### 🎮 Discord Bot (45 أمر)
- **الفئات:**
  - 🎮 ألعاب (10 أوامر)
  - 📊 معلومات (8 أوامر)
  - 🛡️ إدارة (12 أمر)
  - 🎉 أحداث (7 أوامر)
  - ⚙️ عام (8 أوامر)

- **نظام التكاتة المتقدم:**
  - Select Menu (قائمة اختيار) بدل الأزرار
  - تخصيص الخيارات
  - أزرار استقبال وإضافة عضو وإغلاق
  - Embed جميلة ومرتبة

- **أوامر الرسائل:**
  - `/sendmessage` - إرسال رسالة عادية
  - `/sendembed` - إرسال رسالة بـ Embed احترافية

---

## 🚀 كيفية الاستخدام

### تشغيل البوت
```bash
npm run bot
```

### الوصول للبوت
- ربط البوت بـ Discord Server
- استخدام الأوامر مباشرة

---

## 🛠️ البنية التقنية

### Backend (Discord.js + Express + PostgreSQL)

```
src/
├── bot.js                      # البوت الرئيسي
├── deploy-commands.js          # نشر الأوامر
├── commands/                   # جميع الأوامر (45 أمر)
├── events/                     # الأحداث
└── utils/
    ├── db.js                  # اتصال PostgreSQL
    ├── ticketdb.js            # إدارة التكاتة
    └── settingsdb.js          # إدارة الإعدادات
```

---

## 📊 قاعدة البيانات

### PostgreSQL على Render

تم تحويل البيانات من JSON إلى PostgreSQL:

**الجداول:**
- `server_settings` - إعدادات السيرفر
- `ticket_config` - إعدادات نظام التكاتة
- `tickets` - بيانات التكاتة الفعلية

**الإعداد:**
1. اذهب: https://render.com
2. انشئ PostgreSQL Database
3. نسخ الـ `External Database URL`
4. أضفه في `DATABASE_URL`

---

## 🔧 متغيرات البيئة المطلوبة

```env
# Discord Bot
DISCORD_TOKEN=your_bot_token

# Database
DATABASE_URL=postgresql://user:password@host:port/dbname
```

---

## 📦 التثبيت

```bash
# تثبيت جميع الحزم
npm install
```

---

## 🎯 الحالة الحالية

✅ **البوت:**
- 45 أمر شامل بالعربية
- نظام تكاتة متقدم
- متصل بـ PostgreSQL
- الجداول اتنشأت بنجاح

---

## 🔗 الروابط المهمة

- **Bot Invite:** `https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot%20applications.commands`
- **Developer Portal:** `https://discord.com/developers/applications`
- **Render:** `https://render.com`

---

## 📝 الملاحظات

- جميع التواصلات بالعربية
- نظام تكاتة متقدم
- قاعدة بيانات PostgreSQL موثوقة
- جميع الأوامر مع Slash Commands

---

## 🔐 الأمان

- استخدام PostgreSQL بدل JSON
- متغيرات البيئة محفوظة بشكل آمن
- لا تخزين كلمات مرور مباشرة

